# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['urlshorten']

package_data = \
{'': ['*'], 'urlshorten': ['data/*', 'static/*', 'templates/*']}

install_requires = \
['Flask-SQLAlchemy>=2.5.1,<3.0.0',
 'Flask-Script>=2.0.6,<3.0.0',
 'Flask>=2.0.2,<3.0.0',
 'cryptography>=2.8,<3.0',
 'psycopg2>=2.9.2,<3.0.0',
 'url-normalize>=1.4.3,<2.0.0']

setup_kwargs = {
    'name': 'urlshorten',
    'version': '0.1.0',
    'description': 'Simple URL shortener app',
    'long_description': None,
    'author': 'Kevin Zeidler',
    'author_email': 'kzeidler@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
